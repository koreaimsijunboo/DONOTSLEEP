import http.server
import ssl
import os
import base64
import json
import shutil
import socket
import threading
import time

port = 8443
cert_file = './aserver.local+3.pem'
key_file = './aserver.local+3-key.pem'
host = "0.0.0.0"
idle_timeout_sec = int(os.getenv("IDLE_TIMEOUT_SEC", "300"))
last_activity_ts = time.time()
activity_lock = threading.Lock()

# 실행 경로 고정
os.chdir(os.path.dirname(os.path.abspath(__file__)))


def touch_activity():
    global last_activity_ts
    with activity_lock:
        last_activity_ts = time.time()


class MyHandler(http.server.SimpleHTTPRequestHandler):

    # ================= POST =================
    def do_POST(self):
        touch_activity()

        # 이미지 저장
        if self.path == '/save-image':
            length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(length))

            img_data = data['image'].split(',')[1]
            filename = data['filename']

            os.makedirs('captures', exist_ok=True)

            with open(f"captures/{filename}", "wb") as f:
                f.write(base64.b64decode(img_data))

            self.send_response(200)
            self.end_headers()

        # 설정 저장
        elif self.path == '/save-settings':
            length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(length))

            with open("settings.json", "w") as f:
                json.dump(data, f)

            self.send_response(200)
            self.end_headers()

        # 이미지 삭제
        elif self.path == '/delete-image':
            length = int(self.headers['Content-Length'])
            data = json.loads(self.rfile.read(length))

            fpath = f"captures/{data['filename']}"

            if os.path.exists(fpath):
                os.remove(fpath)

            self.send_response(200)
            self.end_headers()

        # 전체 삭제
        elif self.path == '/delete-all':
            if os.path.exists('captures'):
                shutil.rmtree('captures')

            os.makedirs('captures')

            self.send_response(200)
            self.end_headers()

        else:
            self.send_response(404)
            self.end_headers()

    # ================= GET =================
    def do_GET(self):
        touch_activity()

        # 🔥 중요: 기본 페이지 연결
        if self.path == '/':
            self.path = '/index.html'
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

        # 이미지 목록
        elif self.path == '/get-images':
            os.makedirs('captures', exist_ok=True)

            files = os.listdir('captures')
            images = []

            for f in sorted(files, reverse=True):
                fpath = f"captures/{f}"

                if os.path.isfile(fpath):
                    with open(fpath, 'rb') as img_file:
                        img_data = base64.b64encode(img_file.read()).decode()

                        images.append({
                            "filename": f,
                            "img": f"data:image/png;base64,{img_data}",
                            "time": os.path.getmtime(fpath)
                        })

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(images).encode())

        # 설정 불러오기
        elif self.path == '/get-settings':

            if os.path.exists("settings.json"):
                with open("settings.json", "r") as f:
                    data = json.load(f)
            else:
                data = {}

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(data).encode())

        else:
            # 🔥 static 파일 처리 (css/js/img)
            return http.server.SimpleHTTPRequestHandler.do_GET(self)


# ================= 서버 실행 =================

def get_local_ip():
    try:
        # Determine the current LAN IP without sending any traffic.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


httpd = http.server.ThreadingHTTPServer((host, port), MyHandler)


def idle_shutdown_monitor(server):
    while True:
        time.sleep(2)
        with activity_lock:
            idle_for = time.time() - last_activity_ts

        if idle_timeout_sec > 0 and idle_for >= idle_timeout_sec:
            print(f"⏸️  Idle timeout reached ({idle_timeout_sec}s). Server stopped.")
            server.shutdown()
            return

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)

try:
    context.load_cert_chain(certfile=cert_file, keyfile=key_file)
except FileNotFoundError:
    print("❌ 인증서 없음")
    exit(1)

httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

local_ip = get_local_ip()
print(f"🚀 Local: https://localhost:{port}")
print(f"🌐 LAN:   https://{local_ip}:{port}")
if idle_timeout_sec > 0:
    print(f"🕒 Idle auto-stop: {idle_timeout_sec}s (set IDLE_TIMEOUT_SEC=0 to disable)")

threading.Thread(target=idle_shutdown_monitor, args=(httpd,), daemon=True).start()
httpd.serve_forever()
